# mouse_tracker
ROS package for publishing the current position of the mouse. 
