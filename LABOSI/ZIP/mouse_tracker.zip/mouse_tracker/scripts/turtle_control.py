#!/usr/bin/env python3
import rospy
import math
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from geometry_msgs.msg import Point
from pynput.mouse import Controller

class Follow_mouse():
    def mouse_callback(self, data):
        self.mouse_pose=data

    def pose_callback(self, data):
        self.pose=data

    def __init__(self):
        self.pub=rospy.Publisher('turtle1/cmd_vel',Twist,queue_size=1)
        self.rate=rospy.Rate(10) 
 
        self.cmd_vel = Twist()
       
        self.cmd_vel.linear.x = 0.0
        self.cmd_vel.angular.z = 0.0
        self.pose = Pose()
        self.mouse_pose=Point()
        
        rospy.Subscriber("mouse_position", Point ,self.mouse_callback)
        rospy.Subscriber("pose", Pose, self.pose_callback)
        
    def get_distance(self , goal_x , goal_y):
        distance = math.sqrt(pow((goal_x - self.pose.x),2) + pow((goal_y - self.pose.y),2))
        return distance

    def get_ang_distance(self ,goal_x ,goal_y ):
        ang_distance = math.atan2(goal_y - self.pose.y ,goal_x - self.pose.x) - self.pose.theta
        return ang_distance
        
        
    def getX(self, resolution_x):
        faktorX=500/resolution_x
        pose_x=faktorX * self.mouse_pose.x   
        return pose_x
        
    def getY(self, resolution_y):
        faktorY=500/resolution_y
        pose_y= faktorY * (resolution_y - self.mouse_pose.y)  
        
        return pose_y
        
        

    def run(self):
        v_zero=0
        v=1
        velocity_angular=0.3
        res_x=rospy.get_param('resl_x')
        res_y=rospy.get_param('resl_y')
        while not rospy.is_shutdown():
            pose_x=self.getX(res_x)
            pose_y=self.getY(res_y)
            distance= self.get_distance(pose_x, pose_y)
            ang_distance=self.get_distance(pose_x, pose_y)
             
            """
            #the idea was to first turn the turtle towards the mouse 
            if (ang_distance > 1 or ang_distance<-1):  
                self.cmd_vel.angular.z=velocity_angular
                self.cmd_vel.linear.x=v_zero
                self.cmd_vel.linear.y=v_zero
            else: 
            #and then stop rotating the turtle and move it towards the mouse
            #but with this code turtle just stays in one place rotating 
                self.cmd_vel.angular.z=0
                self.cmd_vel.linear.x= math.cos(ang_distance) * v
                self.cmd_vel.linear.y= math.sin(ang_distance) * v """
                
            
            
            if (distance >= 0.1):
                self.cmd_vel.linear.x= math.cos(ang_distance) * v
                self.cmd_vel.linear.y= math.sin(ang_distance) * v
            else:
                self.cmd_vel.linear.x= v_zero
                self.cmd_vel.linear.y= v_zero
                self.cmd_vel.angular.z=v_zero
                
 
           
            self.pub.publish(self.cmd_vel)
            

            
if __name__ =='__main__':

    rospy.init_node('pyclass')

    try:
        ne = Follow_mouse() 
        ne.run()
    except rospy.ROSInterruptException: 
        pass
